import { integer, pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const portfolioWorks = pgTable("portfolio_works", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url"),
  accent: text("accent").notNull().default("violet"),
  projectUrl: text("project_url"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
