"use client";

import { ArrowUpRight, Eye, Layers3 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type Category = "Thumbnail" | "Logo redesign" | "Website";
type Work = {
  id: number | string;
  title: string;
  category: Category;
  description: string;
  accent: string;
  imageUrl?: string | null;
  projectUrl?: string | null;
  visualText?: string;
  visualSub?: string;
  badge?: string;
  isExample?: boolean;
};

const sampleWork: Work[] = [
  {
    id: "sample-thumb-1",
    title: "VANTA RUSH",
    category: "Thumbnail",
    description: "Gaming thumbnail concept — punchy contrast, instant energy.",
    accent: "violet",
    visualText: "RUSH",
    visualSub: "VANTA",
    badge: "YOUTUBE / 01",
    isExample: true,
  },
  {
    id: "sample-logo-1",
    title: "Nova Coffee Co.",
    category: "Logo redesign",
    description: "A bolder, warmer identity made for a coffee label with momentum.",
    accent: "orange",
    visualText: "N",
    visualSub: "NOVA",
    badge: "REDESIGN / 02",
    isExample: true,
  },
  {
    id: "sample-web-1",
    title: "Monday Studio",
    category: "Website",
    description: "Editorial landing page for a creative studio with a tactile feel.",
    accent: "cyan",
    visualText: "m.",
    visualSub: "MADE FOR MONDAY",
    badge: "WEB / 03",
    isExample: true,
  },
  {
    id: "sample-thumb-2",
    title: "THE COMEBACK",
    category: "Thumbnail",
    description: "High-retention visual direction for an esports launch video.",
    accent: "pink",
    visualText: "GO!",
    visualSub: "THE COMEBACK",
    badge: "YOUTUBE / 04",
    isExample: true,
  },
  {
    id: "sample-logo-2",
    title: "Onda Athletics",
    category: "Logo redesign",
    description: "A sharp performance mark built to move effortlessly across apparel.",
    accent: "lime",
    visualText: "O",
    visualSub: "ONDA",
    badge: "REDESIGN / 05",
    isExample: true,
  },
  {
    id: "sample-web-2",
    title: "Kora Skin",
    category: "Website",
    description: "Premium product storytelling with an intentional, calm rhythm.",
    accent: "orange",
    visualText: "KORA",
    visualSub: "SKIN / 001",
    badge: "WEB / 06",
    isExample: true,
  },
];

const filters: Array<"All" | Category> = ["All", "Thumbnail", "Logo redesign", "Website"];

function WorkVisual({ work }: { work: Work }) {
  return (
    <div className={`work-visual work-visual--${work.accent}`}>
      {work.imageUrl ? (
        <div
          className="work-uploaded-image"
          style={{ backgroundImage: `url("${work.imageUrl}")` }}
          aria-label={`${work.title} preview`}
        />
      ) : null}
      <div className="work-grain" />
      <span className="work-stamp">{work.badge ?? "LATEST / ABYAN.FX"}</span>
      <div className="work-orb work-orb--one" />
      <div className="work-orb work-orb--two" />
      <div className="work-type">
        <span>{work.category}</span>
        <Layers3 size={14} strokeWidth={1.7} />
      </div>
      <div className={`work-art work-art--${work.category.toLowerCase().replaceAll(" ", "-")}`}>
        <strong>{work.visualText ?? work.title.slice(0, 2).toUpperCase()}</strong>
        <small>{work.visualSub ?? work.title}</small>
      </div>
    </div>
  );
}

export function WorkShowcase() {
  const [activeFilter, setActiveFilter] = useState<(typeof filters)[number]>("All");
  const [customWork, setCustomWork] = useState<Work[]>([]);

  useEffect(() => {
    fetch("/api/works")
      .then((response) => response.json())
      .then((data: { works?: Work[] }) => setCustomWork(data.works ?? []))
      .catch(() => setCustomWork([]));
  }, []);

  const work = useMemo(() => [...customWork, ...sampleWork], [customWork]);
  const filteredWork = activeFilter === "All" ? work : work.filter((item) => item.category === activeFilter);

  return (
    <section id="work" className="portfolio-section">
      <div className="section-heading section-heading--work">
        <div>
          <p className="eyebrow"><span /> Selected work</p>
          <h2>A little loud.<br /><em>Always intentional.</em></h2>
        </div>
        <p className="section-intro">A mix of visual worlds — designed to stop thumbs, sharpen brands, and make the web feel more alive.</p>
      </div>

      <div className="work-toolbar" aria-label="Filter work by category">
        <div className="filter-list">
          {filters.map((filter) => (
            <button
              className={activeFilter === filter ? "filter-button is-active" : "filter-button"}
              key={filter}
              onClick={() => setActiveFilter(filter)}
            >
              {filter}
            </button>
          ))}
        </div>
        <span className="work-count"><Eye size={15} /> {filteredWork.length.toString().padStart(2, "0")} PROJECTS</span>
      </div>

      <div className="work-grid">
        {filteredWork.map((item, index) => (
          <article className="work-card" key={item.id} style={{ transitionDelay: `${index * 45}ms` }}>
            <WorkVisual work={item} />
            <div className="work-card-info">
              <div>
                <p>{item.category}</p>
                <h3>{item.title}</h3>
              </div>
              {item.projectUrl ? (
                <a href={item.projectUrl} target="_blank" rel="noreferrer" className="round-link" aria-label={`Open ${item.title}`}>
                  <ArrowUpRight size={19} />
                </a>
              ) : (
                <span className="round-link round-link--muted"><ArrowUpRight size={19} /></span>
              )}
            </div>
            <p className="work-description">{item.description}</p>
          </article>
        ))}
      </div>
    </section>
  );
}
