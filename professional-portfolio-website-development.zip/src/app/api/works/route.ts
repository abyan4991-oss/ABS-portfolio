import { desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { portfolioWorks } from "@/db/schema";
import { isOwnerSession, OWNER_COOKIE } from "@/lib/owner-auth";

export const dynamic = "force-dynamic";

const categories = ["Thumbnail", "Logo redesign", "Website"] as const;
const accents = ["violet", "cyan", "orange", "lime", "pink"] as const;

function canManage(request: NextRequest) {
  return isOwnerSession(request.cookies.get(OWNER_COOKIE)?.value);
}

function validOptionalUrl(value: unknown) {
  if (value === undefined || value === null || value === "") return null;
  if (typeof value !== "string") return undefined;
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? url.toString() : undefined;
  } catch {
    return undefined;
  }
}

export async function GET() {
  try {
    const works = await db
      .select()
      .from(portfolioWorks)
      .orderBy(desc(portfolioWorks.createdAt), desc(portfolioWorks.id));
    return NextResponse.json({ works });
  } catch {
    return NextResponse.json({ works: [] });
  }
}

export async function POST(request: NextRequest) {
  if (!canManage(request)) {
    return NextResponse.json({ error: "Owner access required." }, { status: 401 });
  }

  try {
    const body = (await request.json()) as Record<string, unknown>;
    const title = typeof body.title === "string" ? body.title.trim() : "";
    const description = typeof body.description === "string" ? body.description.trim() : "";
    const category = typeof body.category === "string" ? body.category : "";
    const accent = typeof body.accent === "string" ? body.accent : "violet";
    const imageUrl = validOptionalUrl(body.imageUrl);
    const projectUrl = validOptionalUrl(body.projectUrl);

    if (!title || !description || !categories.includes(category as (typeof categories)[number])) {
      return NextResponse.json({ error: "Add a title, category, and short description." }, { status: 400 });
    }
    if (title.length > 80 || description.length > 220 || imageUrl === undefined || projectUrl === undefined) {
      return NextResponse.json({ error: "Please check the length and URL fields." }, { status: 400 });
    }

    const [work] = await db
      .insert(portfolioWorks)
      .values({
        title,
        description,
        category,
        accent: accents.includes(accent as (typeof accents)[number]) ? accent : "violet",
        imageUrl,
        projectUrl,
      })
      .returning();

    return NextResponse.json({ work }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not save this work right now." }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  if (!canManage(request)) {
    return NextResponse.json({ error: "Owner access required." }, { status: 401 });
  }

  const id = Number(request.nextUrl.searchParams.get("id"));
  if (!Number.isInteger(id) || id < 1) {
    return NextResponse.json({ error: "Invalid work item." }, { status: 400 });
  }

  await db.delete(portfolioWorks).where(eq(portfolioWorks.id, id));
  return NextResponse.json({ ok: true });
}
