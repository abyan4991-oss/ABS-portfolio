import { NextRequest, NextResponse } from "next/server";
import {
  createOwnerSession,
  ownerCookieOptions,
  OWNER_COOKIE,
  passwordMatches,
} from "@/lib/owner-auth";

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { password?: unknown };
    const password = typeof body.password === "string" ? body.password : "";

    if (!passwordMatches(password)) {
      return NextResponse.json({ error: "That password is not correct." }, { status: 401 });
    }

    const response = NextResponse.json({ ok: true });
    response.cookies.set(OWNER_COOKIE, createOwnerSession(), ownerCookieOptions);
    return response;
  } catch {
    return NextResponse.json({ error: "Unable to sign in." }, { status: 400 });
  }
}
