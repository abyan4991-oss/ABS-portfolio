import { NextRequest, NextResponse } from "next/server";
import { isOwnerSession, OWNER_COOKIE } from "@/lib/owner-auth";

export async function GET(request: NextRequest) {
  const isOwner = isOwnerSession(request.cookies.get(OWNER_COOKIE)?.value);
  return NextResponse.json({ isOwner });
}
