import Link from "next/link";
import {
  ArrowDown,
  ArrowUpRight,
  Code2,
  Camera,
  Layers2,
  PenTool,
  MoveRight,
  Palette,
  Sparkles,
} from "lucide-react";
import { WorkShowcase } from "@/components/work-showcase";

const instagramUrl = "https://www.instagram.com/abyan.fx?rpxt=eXRpaWQycTNoMXly";

export default function HomePage() {
  return (
    <main>
      <nav className="site-nav">
        <a className="brand" href="#top" aria-label="Abyan FX home">ABYAN<span>.FX</span></a>
        <div className="nav-links">
          <a href="#work">Work</a>
          <a href="#skills">Skills</a>
          <a href="#contact">Contact</a>
        </div>
        <Link className="owner-link" href="/studio">OWNER AREA <span>↗</span></Link>
      </nav>

      <section id="top" className="hero-section">
        <div className="hero-copy">
          <p className="eyebrow eyebrow--hero"><span /> Independent digital creative</p>
          <h1>I make the internet<br /><i>hard to ignore.</i></h1>
          <p className="hero-description">
            I&apos;m <strong>Abyan</strong> — a web developer, thumbnail maker, and logo designer turning bright ideas into standout digital work.
          </p>
          <div className="hero-actions">
            <a className="button button--light" href="#work">See my work <ArrowDown size={17} /></a>
            <a className="text-action" href={instagramUrl} target="_blank" rel="noreferrer">DM on Instagram <ArrowUpRight size={17} /></a>
          </div>
        </div>

        <div className="hero-art" aria-label="Abstract creative workstation illustration">
          <div className="hero-art-glow" />
          <div className="hero-doodle hero-doodle--one">✦</div>
          <div className="hero-doodle hero-doodle--two">◌</div>
          <div className="hero-sticker hero-sticker--top"><span>03</span> CRAFTED<br />FOR IMPACT</div>
          <div className="hero-window">
            <div className="window-bar"><span /><span /><span /><b>abyan.fx / studio</b></div>
            <div className="window-content">
              <p>MAKE IT</p>
              <strong>LOUD<span>.</span></strong>
              <div className="window-shape window-shape--circle" />
              <div className="window-shape window-shape--square" />
              <div className="window-cursor"><MoveRight size={19} /></div>
            </div>
          </div>
          <div className="hero-sticker hero-sticker--bottom"><Sparkles size={16} /> SCROLL STOPPING<br />DESIGN</div>
          <div className="hero-orbit">WEB DEV • DESIGN • BRANDING • WEB DEV • DESIGN • BRANDING •</div>
        </div>

        <div className="hero-footer">
          <span>AVAILABLE FOR SELECT PROJECTS</span>
          <span className="hero-footer-line" />
          <span>BASED ONLINE / WORKING WORLDWIDE</span>
        </div>
      </section>

      <section id="skills" className="skills-section">
        <div className="skills-intro">
          <p className="eyebrow"><span /> What I do</p>
          <h2>Design that gets<br /><em>noticed & remembered.</em></h2>
        </div>
        <div className="service-list">
          <article className="service-card service-card--violet">
            <div className="service-icon"><Code2 size={25} /></div>
            <p className="service-number">01 / DIGITAL</p>
            <h3>Web<br />development</h3>
            <p>Fast, responsive sites with personality built directly for the people using them.</p>
            <div className="service-tags"><span>Next.js</span><span>UI/UX</span><span>Responsive</span></div>
          </article>
          <article className="service-card service-card--cream">
            <div className="service-icon"><Layers2 size={25} /></div>
            <p className="service-number">02 / CONTENT</p>
            <h3>Thumbnail<br />design</h3>
            <p>Visual hooks with the clarity, curiosity, and contrast that earn the click.</p>
            <div className="service-tags"><span>YouTube</span><span>Gaming</span><span>Social</span></div>
          </article>
          <article className="service-card service-card--acid">
            <div className="service-icon"><Palette size={25} /></div>
            <p className="service-number">03 / IDENTITY</p>
            <h3>Logo & brand<br />design</h3>
            <p>Flexible identities that give new and growing brands a confident point of view.</p>
            <div className="service-tags"><span>Logos</span><span>Systems</span><span>Redesigns</span></div>
          </article>
        </div>
      </section>

      <WorkShowcase />

      <section className="marquee-section" aria-label="Creative services">
        <div className="marquee-track">
          <span>DESIGN WITH A PULSE</span><b>✳</b><span>CLICK-WORTHY VISUALS</span><b>✳</b><span>BRANDS WITH CHARACTER</span><b>✳</b><span>DESIGN WITH A PULSE</span><b>✳</b>
        </div>
      </section>

      <section className="about-section">
        <div className="about-art">
          <div className="about-ring about-ring--one" />
          <div className="about-ring about-ring--two" />
          <div className="about-face">
            <span>AB</span>
            <i />
            <i />
            <b>⌁</b>
          </div>
          <p className="about-note">MADE WITH<br />ENERGY + INTENT</p>
        </div>
        <div className="about-copy">
          <p className="eyebrow"><span /> The approach</p>
          <h2>Good design is<br />a <em>feeling</em> first.</h2>
          <p>I pair visual instinct with practical web thinking. The result is work that looks confident, tells a clear story, and is ready to do its job — whether that&apos;s earning a click, a follow, or a customer.</p>
          <div className="about-checks">
            <span><PenTool size={17} /> VISUAL THINKER</span>
            <span><Code2 size={17} /> BUILT FOR THE WEB</span>
          </div>
        </div>
      </section>

      <section id="contact" className="contact-section">
        <div className="contact-noise" />
        <p className="eyebrow eyebrow--contact"><span /> Have a project in mind?</p>
        <h2>Let&apos;s make it<br /><em>unmissable.</em></h2>
        <a className="instagram-button" href={instagramUrl} target="_blank" rel="noreferrer">
          <Camera size={20} /> @abyan.fx <ArrowUpRight size={19} />
        </a>
        <div className="contact-corner contact-corner--one">✦</div>
        <div className="contact-corner contact-corner--two">☻</div>
      </section>

      <footer className="site-footer">
        <a className="brand" href="#top">ABYAN<span>.FX</span></a>
        <p>© 2025 ABYAN.FX — MADE WITH SERIOUS GOOD ENERGY.</p>
        <Link href="/studio">Studio admin</Link>
      </footer>
    </main>
  );
}
