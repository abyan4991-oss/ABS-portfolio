"use client";

import Link from "next/link";
import {
  AlertCircle,
  ArrowLeft,
  Check,
  ExternalLink,
  ImagePlus,
  LockKeyhole,
  LogOut,
  Plus,
  Trash2,
} from "lucide-react";
import { FormEvent, useEffect, useState } from "react";

type Work = {
  id: number;
  title: string;
  category: "Thumbnail" | "Logo redesign" | "Website";
  description: string;
  imageUrl?: string | null;
  projectUrl?: string | null;
  accent: string;
};

type FormValues = {
  title: string;
  category: Work["category"];
  description: string;
  imageUrl: string;
  projectUrl: string;
  accent: string;
};

const blankForm: FormValues = {
  title: "",
  category: "Thumbnail",
  description: "",
  imageUrl: "",
  projectUrl: "",
  accent: "violet",
};

export default function StudioPage() {
  const [isChecking, setIsChecking] = useState(true);
  const [isOwner, setIsOwner] = useState(false);
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [form, setForm] = useState<FormValues>(blankForm);
  const [works, setWorks] = useState<Work[]>([]);
  const [message, setMessage] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/session")
      .then((response) => response.json())
      .then((data: { isOwner?: boolean }) => setIsOwner(Boolean(data.isOwner)))
      .catch(() => setIsOwner(false))
      .finally(() => setIsChecking(false));
  }, []);

  useEffect(() => {
    if (!isOwner) return;
    fetch("/api/works")
      .then((response) => response.json())
      .then((data: { works?: Work[] }) => setWorks(data.works ?? []))
      .catch(() => setWorks([]));
  }, [isOwner]);

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAuthError("");
    const response = await fetch("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    const data = (await response.json()) as { error?: string };
    if (!response.ok) {
      setAuthError(data.error ?? "Unable to sign in.");
      return;
    }
    setPassword("");
    setIsOwner(true);
  }

  async function addWork(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("");
    setIsSaving(true);
    try {
      const response = await fetch("/api/works", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = (await response.json()) as { work?: Work; error?: string };
      if (!response.ok || !data.work) throw new Error(data.error ?? "Could not publish the work.");
      setWorks((current) => [data.work as Work, ...current]);
      setForm(blankForm);
      setMessage("Published! It is now visible in your public work gallery.");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not publish the work.");
    } finally {
      setIsSaving(false);
    }
  }

  async function removeWork(id: number) {
    if (!window.confirm("Remove this work from your public gallery?")) return;
    const response = await fetch(`/api/works?id=${id}`, { method: "DELETE" });
    if (response.ok) setWorks((current) => current.filter((work) => work.id !== id));
  }

  async function signOut() {
    await fetch("/api/admin/logout", { method: "POST" });
    setIsOwner(false);
    setWorks([]);
    setMessage("");
  }

  if (isChecking) {
    return <main className="studio-page studio-loading"><div className="loader-mark">AB</div><p>Opening studio...</p></main>;
  }

  if (!isOwner) {
    return (
      <main className="studio-page">
        <div className="studio-topbar"><Link href="/"><ArrowLeft size={17} /> Back to portfolio</Link><span>ABYAN.FX / PRIVATE</span></div>
        <section className="login-card">
          <div className="login-icon"><LockKeyhole size={27} /></div>
          <p className="eyebrow"><span /> Owner sign in</p>
          <h1>This space is for<br /><em>the maker.</em></h1>
          <p>Sign in to publish new portfolio pieces and manage the work you have already shared.</p>
          <form onSubmit={signIn}>
            <label htmlFor="owner-password">Studio password</label>
            <input
              id="owner-password"
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Enter your password"
              autoComplete="current-password"
              required
            />
            {authError ? <p className="form-error"><AlertCircle size={15} /> {authError}</p> : null}
            <button className="button button--studio" type="submit">Unlock studio <LockKeyhole size={16} /></button>
          </form>
          <small>Protected owner tools · visitors cannot add or delete work.</small>
        </section>
      </main>
    );
  }

  return (
    <main className="studio-page">
      <header className="studio-header">
        <Link className="brand" href="/">ABYAN<span>.FX</span></Link>
        <div><span className="owner-status"><i /> OWNER MODE</span><button onClick={signOut} className="sign-out">Sign out <LogOut size={15} /></button></div>
      </header>
      <section className="studio-hero">
        <p className="eyebrow"><span /> Portfolio control room</p>
        <h1>Make the gallery<br /><em>yours.</em></h1>
        <p>Publish a finished project below. It will appear at the top of the public work section right away.</p>
      </section>

      <section className="studio-grid">
        <article className="publish-card">
          <div className="card-title"><div className="mini-icon"><Plus size={18} /></div><div><p>New portfolio piece</p><h2>Add work</h2></div></div>
          <form className="work-form" onSubmit={addWork}>
            <label>Project title<input value={form.title} onChange={(event) => setForm({ ...form, title: event.target.value })} placeholder="e.g. Nightfall launch thumbnail" maxLength={80} required /></label>
            <div className="form-row">
              <label>Format<select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value as Work["category"] })}><option>Thumbnail</option><option>Logo redesign</option><option>Website</option></select></label>
              <label>Color energy<select value={form.accent} onChange={(event) => setForm({ ...form, accent: event.target.value })}><option value="violet">Electric violet</option><option value="cyan">Digital cyan</option><option value="orange">Warm orange</option><option value="lime">Acid lime</option><option value="pink">Hot pink</option></select></label>
            </div>
            <label>Short description<textarea value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} placeholder="What made this project special?" maxLength={220} rows={3} required /></label>
            <label>Image URL <span className="field-optional">OPTIONAL</span><input type="url" value={form.imageUrl} onChange={(event) => setForm({ ...form, imageUrl: event.target.value })} placeholder="https://..." /></label>
            <label>Project link <span className="field-optional">OPTIONAL</span><input type="url" value={form.projectUrl} onChange={(event) => setForm({ ...form, projectUrl: event.target.value })} placeholder="https://..." /></label>
            {message ? <p className={message.startsWith("Published") ? "form-success" : "form-error"}>{message.startsWith("Published") ? <Check size={15} /> : <AlertCircle size={15} />}{message}</p> : null}
            <button type="submit" className="button button--studio" disabled={isSaving}><ImagePlus size={17} /> {isSaving ? "Publishing..." : "Publish to gallery"}</button>
          </form>
        </article>

        <article className="manage-card">
          <div className="card-title"><div className="mini-icon mini-icon--dark">{works.length.toString().padStart(2, "0")}</div><div><p>Currently live</p><h2>Your uploads</h2></div></div>
          {works.length ? (
            <div className="uploaded-list">
              {works.map((work) => (
                <div className="uploaded-work" key={work.id}>
                  <div className={`upload-swatch upload-swatch--${work.accent}`}>{work.imageUrl ? <span style={{ backgroundImage: `url("${work.imageUrl}")` }} /> : work.title.slice(0, 1)}</div>
                  <div><span>{work.category}</span><h3>{work.title}</h3></div>
                  <div className="upload-actions">{work.projectUrl ? <a href={work.projectUrl} target="_blank" rel="noreferrer" aria-label={`View ${work.title}`}><ExternalLink size={16} /></a> : null}<button onClick={() => removeWork(work.id)} aria-label={`Delete ${work.title}`}><Trash2 size={16} /></button></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-upload"><ImagePlus size={28} /><h3>The wall is waiting.</h3><p>Your uploads will appear here — add your first project using the form.</p></div>
          )}
        </article>
      </section>
    </main>
  );
}
