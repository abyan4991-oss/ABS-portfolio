import { createHmac, timingSafeEqual } from "node:crypto";

export const OWNER_COOKIE = "abyan_owner_session";
const sessionLifetimeSeconds = 60 * 60 * 24 * 14;

// Configure these in the deployment environment. The fallback keeps the starter usable
// locally while still keeping the credential out of browser-delivered code.
const ownerPassword = process.env.ADMIN_PASSWORD ?? "abyan-fx-studio";
const signingSecret = process.env.ADMIN_SESSION_SECRET ?? `${ownerPassword}:portfolio-session`;

function signature(value: string) {
  return createHmac("sha256", signingSecret).update(value).digest("hex");
}

export function passwordMatches(candidate: string) {
  const expected = Buffer.from(ownerPassword);
  const received = Buffer.from(candidate);
  return expected.length === received.length && timingSafeEqual(expected, received);
}

export function createOwnerSession() {
  const expiresAt = Math.floor(Date.now() / 1000) + sessionLifetimeSeconds;
  const payload = `owner.${expiresAt}`;
  return `${payload}.${signature(payload)}`;
}

export function isOwnerSession(value?: string) {
  if (!value) return false;
  const parts = value.split(".");
  if (parts.length !== 3 || parts[0] !== "owner") return false;

  const expiresAt = Number(parts[1]);
  const payload = `${parts[0]}.${parts[1]}`;
  const expectedSignature = signature(payload);
  const validSignature = Buffer.from(parts[2]);
  const expected = Buffer.from(expectedSignature);

  return (
    Number.isFinite(expiresAt) &&
    expiresAt > Math.floor(Date.now() / 1000) &&
    validSignature.length === expected.length &&
    timingSafeEqual(validSignature, expected)
  );
}

export const ownerCookieOptions = {
  httpOnly: true,
  sameSite: "lax" as const,
  secure: process.env.NODE_ENV === "production",
  path: "/",
  maxAge: sessionLifetimeSeconds,
};
